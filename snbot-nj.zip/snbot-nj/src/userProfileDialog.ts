// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

import { MessageFactory, Channels, AgentStatePropertyAccessor, TurnContext, UserState, Attachment } from '@microsoft/agents-hosting'
import {
  ChoiceFactory,
  ChoicePrompt,
  ComponentDialog,
  ConfirmPrompt,
  DialogSet,
  DialogTurnStatus,
  NumberPrompt,
  PromptValidatorContext,
  TextPrompt,
  WaterfallDialog,
  WaterfallStepContext
} from '@microsoft/agents-hosting-dialogs'
import { UserProfile } from './userProfile'

const CHOICE_PROMPT = 'CHOICE_PROMPT'
const CONFIRM_PROMPT = 'CONFIRM_PROMPT'
const EMAIL_PROMPT = 'EMAIL_PROMPT'
const USER_PROFILE = 'USER_PROFILE'
const WATERFALL_DIALOG = 'WATERFALL_DIALOG'

export class UserProfileDialog extends ComponentDialog {
  private userProfile: AgentStatePropertyAccessor<UserProfile>

  constructor (userState: UserState) {
    super('userProfileDialog')

    this.userProfile = userState.createProperty(USER_PROFILE)

    this.addDialog(new TextPrompt(EMAIL_PROMPT))
    this.addDialog(new ChoicePrompt(CHOICE_PROMPT))
    this.addDialog(new ConfirmPrompt(CONFIRM_PROMPT))

    this.addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
      this.emailStep.bind(this),
      this.emailConfirmStep.bind(this),
      this.confirmStep.bind(this)
    ]))

    this.initialDialogId = WATERFALL_DIALOG
  }

  /**
     * The run method handles the incoming activity (in the form of a TurnContext) and passes it through the dialog system.
     * If no dialog is active, it will start the default dialog.
     * @param {*} turnContext
     * @param {*} accessor
     */
  public async run (turnContext: TurnContext, accessor: AgentStatePropertyAccessor) {
    const dialogSet = new DialogSet(accessor)
    dialogSet.add(this)

    const dialogContext = await dialogSet.createContext(turnContext)
    const results = await dialogContext.continueDialog()
    if (results.status === DialogTurnStatus.empty) {
      await dialogContext.beginDialog(this.id)
    }
  }

  private async emailStep(stepContext: WaterfallStepContext<UserProfile>) {
    // Prompt the user for their email address
    return await stepContext.prompt('EMAIL_PROMPT', {
      prompt: 'Please enter your email address.',
    });
  }

  private async emailConfirmStep(stepContext: WaterfallStepContext<UserProfile>) {
    // Save the email address to the UserProfile
    const userProfile = stepContext.options || new UserProfile();
    userProfile.email = stepContext.result; // Capture the email address
    await this.userProfile.set(stepContext.context, userProfile); // Save to UserState

    // Confirm the email address with the user
    await stepContext.context.sendActivity(`Thanks! I've saved your email as: ${userProfile.email}`);
    return await stepContext.next();
  }

  private async confirmStep (stepContext: WaterfallStepContext<UserProfile>) {
    let msg = 'Thanks.';
    if (stepContext.result) {
      msg += ' Your profile saved successfully.';
    } else {
      msg += ' Your profile will not be kept.';
    }

    await stepContext.context.sendActivity(msg);

    // End the dialog
    return await stepContext.endDialog();
  }
}
