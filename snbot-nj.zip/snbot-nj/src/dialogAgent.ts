// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

import { ActivityHandler, AgentState, ConversationState, TurnContext, UserState, AgentStatePropertyAccessor } from '@microsoft/agents-hosting';
import { DialogState } from '@microsoft/agents-hosting-dialogs';

export class DialogAgent extends ActivityHandler {
  private conversationState: ConversationState;
  private userState: UserState;
  private dialogState: AgentStatePropertyAccessor<DialogState>;

  constructor(conversationState: ConversationState, userState: UserState) {
    super();

    if (!conversationState) throw new Error('[DialogBot]: Missing parameter. conversationState is required');
    if (!userState) throw new Error('[DialogBot]: Missing parameter. userState is required');

    this.conversationState = conversationState;
    this.userState = userState;

    // Create a property accessor for dialog state
    this.dialogState = this.conversationState.createProperty<DialogState>('DialogState');

    this.onMembersAdded(async (context: TurnContext, next) => {
      const membersAdded = context.activity.membersAdded;
      const welcomeText = 'Welcome to JCI ServiceNow Bot! You can ask me any question.';

      if (membersAdded) {
        for (const member of membersAdded) {
          if (member.id !== (context.activity.recipient?.id ?? '')) {
            await context.sendActivity(welcomeText);
          }
        }
      }

      await next();
    });

    this.onMessage(async (context: TurnContext, next) => {
      console.log('Running dialog with Message Activity.');

      // Use a default email address
      const defaultEmail = 'pooja.5.sharma@jci.com';

      // Get the user's question
      const userInput = (context.activity.text ?? '').trim();
      console.log('User input:', userInput); // Debugging log

      if (!userInput) {
        await context.sendActivity('Sorry, I did not understand your question. Please try again.');
        return;
      }

      // Prepare the API payload
      const apiPayload = {
        messages: [
          {
            role: 'user',
            content: userInput,
            user: defaultEmail,
          },
        ],
      };

      // Log the payload for debugging
      console.log('Sending JSON payload to API:', JSON.stringify(apiPayload, null, 2));

      // Call the external API
      try {
        const apiResponse = await fetch('https://app-python.bluepond-0e1e5d1a.eastus2.azurecontainerapps.io/service-now', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(apiPayload),
        });

        if (!apiResponse.ok) {
          throw new Error(`API call failed with status ${apiResponse.status}`);
        }

        interface ApiResponse {
          result?: {
            content?: string;
          };
        }

        const apiResult = (await apiResponse.json()) as ApiResponse;
        const apiContent = apiResult.result?.content || 'Sorry, I could not process your request.';

        // Send the API response back to the user
        await context.sendActivity(`Here's the response: ${apiContent}`);
      } catch (error) {
        console.error('Error calling API:', error);
        await context.sendActivity('An error occurred while processing your request. Please try again later.');
      }

      await next();
    });

    this.onDialog(async (context, next) => {
      // Save any state changes
      await this.conversationState.saveChanges(context, false);
      await this.userState.saveChanges(context, false);
      await next();
    });
  }
}
