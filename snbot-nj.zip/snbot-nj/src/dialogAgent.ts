// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

import { ActivityHandler, AgentState, ConversationState, TurnContext, UserState, AgentStatePropertyAccessor } from '@microsoft/agents-hosting';
import { DialogState } from '@microsoft/agents-hosting-dialogs';
import * as dotenv from 'dotenv';
dotenv.config();

export class DialogAgent extends ActivityHandler {
  private conversationState: ConversationState;
  private userState: UserState;
  private dialogState: AgentStatePropertyAccessor<DialogState>;

  constructor(conversationState: ConversationState, userState: UserState) {
    super();

    if (!conversationState) throw new Error('[DialogBot]: Missing parameter. conversationState is required');
    if (!userState) throw new Error('[DialogBot]: Missing parameter. userState is required');

    this.conversationState = conversationState;
    this.userState = userState;

    // Create a property accessor for dialog state
    this.dialogState = this.conversationState.createProperty<DialogState>('DialogState');

    this.onMembersAdded(async (context: TurnContext, next) => {
      const membersAdded = context.activity.membersAdded;
      const welcomeText = 'Welcome to JCI ServiceNow Bot! You can ask me any question.';

      if (membersAdded) {
        for (const member of membersAdded) {
          if (member.id !== (context.activity.recipient?.id ?? '')) {
            // Log or use the user's name or ID
            const userName = member.name || 'Unknown User';
            const userId = member.id;
            console.log(`New user added: Name = ${userName}, ID = ${userId}`);

            // Send a personalized welcome message
            await context.sendActivity(`Hello ${userName}, ${welcomeText}`);
          }
        }
      }

      await next();
    });

    this.onMessage(async (context: TurnContext, next) => {
      console.log('Running dialog with Message Activity.');

      // Read the default email address from the .env file
      const defaultEmail = process.env.DEFAULT_EMAIL || '';
      const serviceNowApi = process.env.SERVICE_NOW_API || '';

      // Log the user information
      console.log(`Message received from: Name = ${context.activity.from?.name}, ID = ${context.activity.from?.id}`);

      // Get the user's name or ID from the context
      const userName = (context.activity.from?.name === 'Alex Wilber' || context.activity.from?.name === 'default' || !context.activity.from?.name) ? 'Unknown User' : context.activity.from?.name;
      const userId = (context.activity.from?.id === 'user-id-0' || !context.activity.from?.id) ? 'Unknown ID': context.activity.from?.id;
      console.log(`Rendered Name = ${userName}, ID = ${userId}`);

      // Use defaultEmail if the user is "Unknown User"
      const userEmail = userName === 'Unknown User' ? defaultEmail : `${userName}@jci.com`;

      // Get the user's question
      const userInput = (context.activity.text ?? '').trim();
      console.log('User input:', userInput); // Debugging log

      if (!userInput) {
        await context.sendActivity('Sorry, I did not understand your question. Please try again.');
        return;
      }

      // Prepare the API payload
      const apiPayload = {
        messages: [
          {
            role: 'user',
            content: userInput,
            user: userEmail,
          },
        ],
      };

      // Log the payload for debugging
      console.log('Sending JSON payload to API:', JSON.stringify(apiPayload, null, 2));

      // Call the external API
      try {
        const apiResponse = await fetch(serviceNowApi, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(apiPayload),
        });

        if (!apiResponse.ok) {
          throw new Error(`API call failed with status ${apiResponse.status}`);
        }

        interface ApiResponse {
          result?: {
            content?: string;
          };
        }

        const apiResult = (await apiResponse.json()) as ApiResponse;
        const apiContent = apiResult.result?.content || 'Sorry, I could not process your request.';

        // Send the API response back to the user
        await context.sendActivity(`Here's the response: ${apiContent}`);
      } catch (error) {
        console.error('Error calling API:', error);
        await context.sendActivity('An error occurred while processing your request. Please try again later.');
      }

      await next();
    });

    this.onDialog(async (context, next) => {
      // Save any state changes
      await this.conversationState.saveChanges(context, false);
      await this.userState.saveChanges(context, false);
      await next();
    });
  }
}
