import express, { Response } from 'express'
import { DialogAgent } from './dialogAgent'
import { UserProfileDialog } from './userProfileDialog'
import { CloudAdapter, authorizeJWT, loadAuthConfigFromEnv, UserState, ConversationState, MemoryStorage, Request } from '@microsoft/agents-hosting'
import { version as sdkVersion } from '@microsoft/agents-hosting/package.json'

const authConfig = loadAuthConfigFromEnv()

const adapter = new CloudAdapter(authConfig)

// Create conversation and user state
const memoryStorage = new MemoryStorage()
const conversationState = new ConversationState(memoryStorage)
const userState = new UserState(memoryStorage)

// Create the dialog
const userProfileDialog = new UserProfileDialog(userState)

// Create the bot
const myBot = new DialogAgent(conversationState, userState)

const app = express()

app.use(express.json())
app.use(authorizeJWT(authConfig))

app.post('/api/messages', async (req: Request, res: Response) => {
  // console.log(req.body)
  // console.log('req.user', req.user)
  await adapter.process(req, res, async (context) => await myBot.run(context))
})

const port = process.env.PORT || 3978
app.listen(port, () => {
  console.log(`\nServer listening to port ${port} on sdk ${sdkVersion} for appId ${authConfig.clientId} debug ${process.env.DEBUG}`)
}).on('error', console.error)
