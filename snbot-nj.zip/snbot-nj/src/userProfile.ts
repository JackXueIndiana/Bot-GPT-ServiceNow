// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

import { Attachment } from '@microsoft/agents-hosting'

export class UserProfile {
  constructor (
    public email: string = ''
  ) {
    this.email = email
  }
}
