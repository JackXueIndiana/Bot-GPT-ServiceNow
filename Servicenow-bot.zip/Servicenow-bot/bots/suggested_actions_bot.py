# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from botbuilder.core import ActivityHandler, MessageFactory, TurnContext
from botbuilder.schema import ChannelAccount, CardAction, ActionTypes, SuggestedActions
import requests  # Add this import at the top of the file

from dotenv import load_dotenv
import os


class SuggestActionsBot(ActivityHandler):
    """
    This bot will respond to the user's input with suggested actions.
    Suggested actions enable your bot to present buttons that the user
    can tap to provide input.
    """
    def __init__(self): 
        load_dotenv()
        self.app_url = os.getenv("APP_URL")
        self.default_user_name = os.getenv("DEFAULT_USER_NAME")

    async def on_members_added_activity(
        self, members_added: [ChannelAccount], turn_context: TurnContext
    ):
        """
        Send a welcome message to the user and tell them what actions they may perform to use this bot
        """

        return await self._send_welcome_message(turn_context)

    async def on_message_activity(self, turn_context: TurnContext):
        """
        Respond to the users choice and display the suggested actions again.
        """

        text = turn_context.activity.text.lower()
        member_name = turn_context.activity.from_property.name 
        if member_name is None or member_name == "User":
            member_name=self.default_user_name
            print("use default name:{}".format(member_name))
        else: 
            member_name = member_name.lower()
            print("use member name:{}".format(member_name))
            
        response_text = self._process_input(text, member_name)

        await turn_context.send_activity(MessageFactory.text(response_text))

        return await self._send_suggested_actions(turn_context)

    async def _send_welcome_message(self, turn_context: TurnContext):
        for member in turn_context.activity.members_added:
            if member.id != turn_context.activity.recipient.id:
                await turn_context.send_activity(
                    MessageFactory.text(
                        f"Welcome to JCI NowBot {member.name}."
                        f" I can help you with your queries."
                    )
                )

                await self._send_suggested_actions(turn_context)

    def _process_input(self, text: str, member_name: str):
        try:
            # Example usage
            json_input ={
                "messages": [
                    {
                        "role": "user",
                        "content": text,
                        "user": member_name
                    }
                ]
            }
            
            # Make a GET request to the API with the user's input as a query parameter
            response = requests.post(self.app_url, json=json_input)
            response.raise_for_status()  # Raise an exception for HTTP errors

            # Parse the API response (assuming it returns JSON with a 'message' field)
            api_response_result = response.json().get("result", "")
            return api_response_result.get("content", "Sorry, I couldn't process your request.")
        
        except requests.RequestException as e:
            # Handle any errors that occur during the API call
            return f"An error occurred while processing your request: {str(e)}"

    async def _send_suggested_actions(self, turn_context: TurnContext):
        """
        Creates and sends an activity with suggested actions to the user. When the user
        clicks one of the buttons the text value from the "CardAction" will be displayed
        in the channel just as if the user entered the text. There are multiple
        "ActionTypes" that may be used for different situations.
        """

        reply = MessageFactory.text("What is your question?")

        return await turn_context.send_activity(reply)
