#!/usr/bin/env python3
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

import os

""" Bot Configuration """


class DefaultConfig:
    """ Bot Configuration """

    PORT = 3978
    HOST = "0.0.0.0"
    '''
    APP_ID = os.environ.get("MicrosoftAppId", "93613519-de7c-4e69-a570-a6d15b21fb4d")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "xb68Q~UECV_8Leow1s_tAiJ_ecBfA7-v-QmWDdzG")
    APP_TYPE = os.environ.get("MicrosoftAppType", "Multitenant")
    APP_TENANTID = os.environ.get("MicrosoftAppTenantId", "16b3c013-d300-468d-ac64-7eda0820b6d3")
    '''
    APP_ID = os.environ.get("MicrosoftAppId", "")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "")
    APP_TYPE = os.environ.get("MicrosoftAppType", "Multitenant")
    APP_TENANTID = os.environ.get("MicrosoftAppTenantId", "")
