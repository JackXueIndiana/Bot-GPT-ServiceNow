from agents import function_tool
import json
import os
import requests
from datetime import datetime


@function_tool
def get_service_now(jci_user_email: str, query: str) -> str:
    print("[debug] get_service_now called for user:", jci_user_email)
    print("[debug] query:", query)
    
    # Create JSON data with the specified format
    json_data = {
        "messages": [
            {
                "role": "user",
                "content": query,
                "user": jci_user_email
            }
        ]
    }
    
    # Post the JSON to ServiceNow
    service_now_url = os.environ.get("SERVICE_NOW_URL")
    
    try:
        # Send POST request with JSON data
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        
        print(f"[debug] Posting to ServiceNow URL: {service_now_url}")
        response = requests.post(service_now_url, json=json_data, headers=headers, timeout=30)
        
        # Check if request was successful
        response.raise_for_status()
        
        print(f"[debug] ServiceNow response status: {response.status_code}")
        
        # Try to get JSON response, fallback to text if not JSON
        try:
            response_data = response.json()
            print(f"[debug] ServiceNow response data: {response_data}")
            return response_data
        except json.JSONDecodeError:
            response_text = response.text
            print(f"[debug] ServiceNow response text: {response_text}")
            return f"ServiceNow response for user {jci_user_email}: {response_text}"
            
    except requests.exceptions.Timeout:
        error_msg = f"Timeout error when contacting ServiceNow for user {jci_user_email}"
        print(f"[error] {error_msg}")
        return error_msg
    except requests.exceptions.ConnectionError:
        error_msg = f"Connection error when contacting ServiceNow for user {jci_user_email}"
        print(f"[error] {error_msg}")
        return error_msg
    except requests.exceptions.HTTPError as e:
        error_msg = f"HTTP error {e.response.status_code} when contacting ServiceNow for user {jci_user_email}: {e.response.text}"
        print(f"[error] {error_msg}")
        return error_msg
    except Exception as e:
        error_msg = f"Unexpected error when contacting ServiceNow for user {jci_user_email}: {str(e)}"
        print(f"[error] {error_msg}")
        return error_msg
