from __future__ import annotations

from typing import Union
from microsoft.agents.hosting.core import ActivityHandler, MessageFactory, TurnContext
from microsoft.agents.activity import ChannelAccount, Attachment

from agents import (
    Agent as OpenAIAgent,
    Model,
    ModelProvider,
    OpenAIChatCompletionsModel,
    RunConfig,
    Runner,
)
from openai import AsyncAzureOpenAI
from pydantic import BaseModel, Field

from tools.get_weather_tool import get_weather
from tools.date_time_tool import get_date
from tools.get_service_now_tool import get_service_now


class BotAgentResponse(BaseModel):
    contentType: str = Field(pattern=r"^(Text|AdaptiveCard)$")
    content: Union[dict, str]


class BotAgent(ActivityHandler):
    jci_user_email: str = ""
    def __init__(self, client: AsyncAzureOpenAI):
        self.agent = OpenAIAgent(
            name="WeatherAgent",
            instructions=""""
            You are a friendly assistant that 
            1. helps people find a weather forecast for a given time and place. Or
            2. call web service service_now to get information about a service request.
            You will be provided with a JCI email address, which you must use to call the ServiceNow API. 
            Do not reply with MD format nor plain text. You can ONLY respond in JSON format with the following JSON schema
            {
                "contentType": "'Text' if you don't have a forecast or 'AdaptiveCard' if you do",
                "content": "{The content of the response, may be plain text, or JSON based adaptive card}"
            }
            You may ask follow up questions until you have enough information to answer the customers question,
            but once you have a forecast forecast, make sure to format it nicely using an adaptive card.
            When call get_weather, you must provide the jci_user_email, city and date.
            When call get_service_now, you must provide the jci_user_email, and query.
            """,
            tools=[get_weather, get_date, get_service_now],
        )

        class CustomModelProvider(ModelProvider):
            def get_model(self, model_name: str | None) -> Model:
                return OpenAIChatCompletionsModel(
                    model=model_name or "gpt-4.1", openai_client=client
                )

        self.custom_model_provider = CustomModelProvider()

    async def on_members_added_activity(
        self, members_added: list[ChannelAccount], turn_context: TurnContext
    ):
        for member in members_added:
            if self.jci_user_email:
                member.name = self.jci_user_email
            if member.id != turn_context.activity.recipient.id:
                await turn_context.send_activity("Hello and welcome! May I hve your JCI email address?")

    async def on_message_activity(self, turn_context: TurnContext):
        text = turn_context.activity.text
        if text.strip().lower().endswith("@jci.com"):
            self.jci_user_email = str(text).strip().lower()
            await turn_context.send_activity(f"Thank you for providing your JCI email address: {self.jci_user_email}. Now, how can I assist you?")
            return
        
        # Exit if the user says good bye or bye.
        if text.strip().lower() in ["good bye", "bye"]:
            await turn_context.send_activity("Good bye! Have a nice day!")
            return
        
        # If the user has not provided a JCI email address, ask for it.
        if len(self.jci_user_email) > 0 and text.count(self.jci_user_email) == 0:
            text = turn_context.activity.text + f" jci_user_email = {self.jci_user_email}"
            
        response = await Runner.run(
            self.agent,
            text,
            run_config=RunConfig(
                model_provider=self.custom_model_provider,
                tracing_disabled=True,
            ),
        )
        if len(self.jci_user_email) == 0 and str(response.input).strip().lower().endswith("@jci.com"):
            self.jci_user_email = str(response.input).strip().lower()
            await turn_context.send_activity(f"Thank you for providing your JCI email address: {self.jci_user_email}. Now, how can I assist you with the weather forecast?")
            return
        
        llm_response = BotAgentResponse.model_validate_json(
            response.final_output
        )
        if llm_response.contentType == "AdaptiveCard":
            activity = MessageFactory.attachment(
                Attachment(
                    content_type="application/vnd.microsoft.card.adaptive",
                    content=llm_response.content,
                )
            )
        elif llm_response.contentType == "Text":
            activity = MessageFactory.text(llm_response.content)

        return await turn_context.send_activity(activity)
